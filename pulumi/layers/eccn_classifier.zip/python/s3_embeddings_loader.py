#!/usr/bin/env python3
"""
S3 Embeddings載入器
簡化版本，直接從S3載入embeddings
"""

import boto3
import pickle
import logging

def load_eccn_embeddings(bucket_name, key, aws_access_key, aws_secret_key, region='us-east-1'):
    """從S3載入ECCN embeddings"""
    try:
        s3_client = boto3.client(
            's3',
            aws_access_key_id=aws_access_key,
            aws_secret_access_key=aws_secret_key,
            region_name=region
        )
        
        response = s3_client.get_object(Bucket=bucket_name, Key=key)
        embeddings = pickle.loads(response['Body'].read())
        
        logging.info(f"Successfully loaded {len(embeddings)} ECCN embeddings")
        return embeddings
        
    except Exception as e:
        logging.error(f"Failed to load embeddings: {str(e)}")
        return None