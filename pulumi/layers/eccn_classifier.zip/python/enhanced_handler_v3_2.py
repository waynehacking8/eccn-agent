#!/usr/bin/env python3
"""
ECCN分類增強型Lambda Handler v3.2
整合外部工具 (Mouser API, WebSearch) 提升分類準確性
"""

import json
import logging
import boto3
import pickle
import re
import time
import os
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime

# 導入工具模組
from enhanced_tool_system import ECCNToolEnhancer
from mouser_api_integration import MouserAPIClient
from websearch_integration import ECCNWebSearcher

# AWS服務設定
AWS_ACCESS_KEY_ID = "AKIAZQ3DOKWNSVXGN3P6"
AWS_SECRET_ACCESS_KEY = "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"
AWS_REGION = os.environ.get('CUSTOM_AWS_REGION', 'us-east-1')

# S3和Bedrock配置
S3_BUCKET_NAME = os.environ.get('S3_BUCKET_NAME', 'eccn-enhanced-pipeline-data-us-east-1')
EMBEDDINGS_KEY = "eccn_embeddings.pkl"
BEDROCK_MODEL_ID = "us.anthropic.claude-3-5-sonnet-20241022-v2:0"

# 工具配置
TOOLS_CONFIG = {
    'mouser_api': {
        'enabled': True,
        'api_key': "a4ae0035-f741-40dd-bf18-6d88ce443849",  # Mouser API密鑰
        'timeout': 15
    },
    'websearch': {
        'enabled': True,
        'timeout': 30
    },
    'tool_enhancement': {
        'enabled': True,
        'confidence_threshold': 0.6,  # 工具增強的信心閾值
        'override_threshold': 0.8     # 覆蓋原始分類的閾值
    }
}

class EnhancedECCNClassifier:
    """增強型ECCN分類器"""
    
    def __init__(self):
        self.logger = self._setup_logging()
        
        # AWS服務初始化
        self.s3_client = boto3.client(
            's3',
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
            region_name=AWS_REGION
        )
        
        self.bedrock_client = boto3.client(
            'bedrock-runtime',
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
            region_name=AWS_REGION
        )
        
        # 工具初始化
        self.tool_enhancer = ECCNToolEnhancer(self.logger)
        self.mouser_client = MouserAPIClient(
            api_key=TOOLS_CONFIG['mouser_api']['api_key'],
            logger=self.logger
        )
        self.web_searcher = ECCNWebSearcher(self.logger)
        
        # 載入embeddings
        self.eccn_embeddings = self._load_embeddings()
        
        self.logger.info("✅ 增強型ECCN分類器初始化完成")
    
    def _setup_logging(self) -> logging.Logger:
        """設置日誌"""
        logger = logging.getLogger()
        logger.setLevel(logging.INFO)
        
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        
        return logger
    
    def _load_embeddings(self) -> Optional[Dict]:
        """載入ECCN embeddings"""
        try:
            self.logger.info("📥 載入ECCN embeddings...")
            
            response = self.s3_client.get_object(
                Bucket=S3_BUCKET_NAME,
                Key=EMBEDDINGS_KEY
            )
            
            embeddings = pickle.loads(response['Body'].read())
            self.logger.info(f"✅ 成功載入 {len(embeddings)} 個ECCN嵌入向量")
            return embeddings
            
        except Exception as e:
            self.logger.error(f"❌ 載入embeddings失敗: {str(e)}")
            return None
    
    def classify_product(self, s3_key: str, product_model: str, debug: bool = False) -> Dict:
        """
        增強型產品分類
        
        Args:
            s3_key: S3中PDF內容的鍵值
            product_model: 產品型號
            debug: 是否開啟詳細調試資訊
            
        Returns:
            分類結果字典
        """
        try:
            self.logger.info(f"🚀 開始增強型ECCN分類: {product_model}")
            
            start_time = time.time()
            
            # 1. 獲取PDF內容
            pdf_content = self._get_pdf_content(s3_key)
            if not pdf_content:
                return self._create_error_response("無法獲取PDF內容", s3_key)
            
            # 2. 執行優先級分類系統: Mouser > LLM(PDF+Embeddings) > WebSearch強化
            enhanced_classification = self._classify_with_priority_system(
                product_model, pdf_content, debug
            )
            
            # 向後兼容性處理
            if not enhanced_classification:
                self.logger.warning("⚠️ 優先級系統失敗，使用基礎分類")
                enhanced_classification = self._perform_base_classification(pdf_content, product_model, debug)
            
            # 4. 最終結果處理
            processing_time = time.time() - start_time
            enhanced_classification['processing_time'] = f"{processing_time:.2f}s"
            enhanced_classification['timestamp'] = datetime.now().isoformat()
            enhanced_classification['version'] = "v3.2_priority_system"
            
            # 5. 調試資訊
            if debug:
                enhanced_classification['debug_info'] = {
                    'tools_enabled': TOOLS_CONFIG['tool_enhancement']['enabled'],
                    'pdf_content_length': len(pdf_content),
                    'priority_system_used': True,
                    'processing_steps': [
                        'pdf_content_retrieval',
                        'priority_system_classification',
                        'mouser_api_check',
                        'llm_pipeline_check',
                        'websearch_enhancement_check',
                        'result_finalization'
                    ]
                }
            
            self.logger.info(f"✅ 分類完成: {enhanced_classification.get('eccn_code', 'Unknown')} ({processing_time:.2f}s)")
            return self._create_success_response(enhanced_classification)
            
        except Exception as e:
            self.logger.error(f"❌ 分類失敗: {str(e)}")
            return self._create_error_response(f"分類過程發生錯誤: {str(e)}", s3_key)
    
    def _get_pdf_content(self, s3_key: str) -> Optional[str]:
        """從S3獲取PDF內容"""
        try:
            self.logger.info(f"📄 獲取PDF內容: {s3_key}")
            
            response = self.s3_client.get_object(
                Bucket=S3_BUCKET_NAME,
                Key=s3_key
            )
            
            content = response['Body'].read().decode('utf-8')
            
            # 如果是JSON格式，提取content欄位
            if s3_key.endswith('.json'):
                try:
                    json_data = json.loads(content)
                    content = json_data.get('content', content)
                except json.JSONDecodeError:
                    pass
            
            self.logger.info(f"✅ PDF內容獲取成功 ({len(content)} 字符)")
            return content
            
        except Exception as e:
            self.logger.error(f"❌ 獲取PDF內容失敗: {str(e)}")
            return None
    
    def _perform_base_classification(self, pdf_content: str, product_model: str, debug: bool) -> Dict:
        """執行基礎AI分類"""
        try:
            self.logger.info("🤖 執行基礎AI分類...")
            
            # 使用embeddings進行相似度搜索
            similar_eccns = self._find_similar_eccns(pdf_content)
            
            # 構建分類prompt
            system_prompt = self._build_classification_prompt(similar_eccns)
            
            # 調用Bedrock
            user_message = f"""
            產品型號: {product_model}
            
            PDF技術內容:
            {pdf_content[:4000]}  # 限制長度避免token超限
            
            請根據技術規格進行ECCN分類。
            """
            
            bedrock_response = self._call_bedrock(system_prompt, user_message)
            
            # 解析回應
            classification_result = self._parse_bedrock_response(bedrock_response)
            
            self.logger.info(f"🤖 基礎分類完成: {classification_result.get('eccn_code', 'Unknown')}")
            return classification_result
            
        except Exception as e:
            self.logger.error(f"❌ 基礎分類失敗: {str(e)}")
            return {
                'eccn_code': 'EAR99',
                'confidence': 'low',
                'method': 'fallback',
                'reasoning': f'基礎分類失敗，使用預設值: {str(e)}'
            }
    
    def _classify_with_priority_system(self, product_model: str, pdf_content: str, debug: bool = False) -> Dict:
        """優先級分類系統: Mouser > LLM(PDF+Embeddings) > WebSearch信心度強化"""
        try:
            self.logger.info("🎯 開始優先級分類系統...")
            
            # 步驟1: Mouser API優先查詢
            if TOOLS_CONFIG['mouser_api']['enabled']:
                self.logger.info("🥇 第一優先級: Mouser API查詢...")
                mouser_result = self.mouser_client.get_eccn_info(product_model)
                if mouser_result and mouser_result.get('eccn_code') not in ['N/A', None, '']:
                    self.logger.info(f"✅ Mouser API成功: {mouser_result.get('eccn_code')}")
                    return {
                        'eccn_code': mouser_result.get('eccn_code'),
                        'confidence': mouser_result.get('confidence', 'high'),
                        'method': 'mouser_api_priority',
                        'reasoning': f"Mouser官方資料確認: {mouser_result.get('eccn_code')}",
                        'source': 'mouser_api',
                        'mouser_data': mouser_result,
                        'version': 'v3.2_priority_system'
                    }
                else:
                    self.logger.info("⚠️ Mouser API無結果，進入LLM pipeline...")
            
            # 步驟2: LLM Pipeline (PDF + Embeddings) - 原本的完整pipeline
            self.logger.info("🥈 第二優先級: LLM Pipeline (PDF+Embeddings)...")
            llm_result = self._perform_original_llm_classification(pdf_content, product_model, debug)
            
            # 步驟3: WebSearch信心度強化
            if TOOLS_CONFIG['websearch']['enabled'] and llm_result.get('confidence') in ['low', 'medium']:
                self.logger.info("🥉 WebSearch信心度強化...")
                enhanced_result = self._enhance_with_websearch(llm_result, product_model, pdf_content)
                return enhanced_result
            
            return llm_result
            
        except Exception as e:
            self.logger.error(f"❌ 優先級分類失敗: {str(e)}")
            return {
                'eccn_code': 'EAR99',
                'confidence': 'low', 
                'method': 'error_fallback',
                'reasoning': f'分類系統錯誤，使用預設值: {str(e)}'
            }
    
    def _perform_original_llm_classification(self, pdf_content: str, product_model: str, debug: bool = False) -> Dict:
        """執行原本的LLM分類pipeline (PDF + Embeddings)"""
        try:
            self.logger.info("🤖 執行原本LLM Pipeline...")
            
            # 使用原本的基礎分類邏輯
            base_result = self._perform_base_classification(pdf_content, product_model, debug)
            
            return {
                'eccn_code': base_result.get('eccn_code', 'EAR99'),
                'confidence': base_result.get('confidence', 'medium'),
                'method': 'llm_pipeline',
                'reasoning': base_result.get('reasoning', 'LLM分析結合PDF內容和embeddings'),
                'source': 'llm_with_embeddings',
                'base_classification': base_result,
                'version': 'v3.2_priority_system'
            }
            
        except Exception as e:
            self.logger.error(f"❌ LLM Pipeline失敗: {str(e)}")
            return {
                'eccn_code': 'EAR99',
                'confidence': 'low',
                'method': 'llm_pipeline_error',
                'reasoning': f'LLM分析失敗: {str(e)}'
            }
    
    def _enhance_with_websearch(self, llm_result: Dict, product_model: str, pdf_content: str) -> Dict:
        """使用WebSearch強化LLM結果的信心度"""
        try:
            self.logger.info("🌐 WebSearch信心度強化...")
            
            # 執行WebSearch
            manufacturer = self._extract_manufacturer(pdf_content, product_model)
            web_results = self.web_searcher.search_eccn_information(product_model, manufacturer)
            
            if not web_results:
                self.logger.info("⚠️ WebSearch無結果，保持LLM結果")
                return llm_result
            
            llm_eccn = llm_result.get('eccn_code', '')
            
            # 計算WebSearch對LLM結果的支持度
            support_count = 0
            total_web_results = len(web_results[:3])  # 只考慮前3個結果
            
            for result in web_results[:3]:
                if result.get('eccn_code') == llm_eccn:
                    support_count += 1
            
            support_ratio = support_count / total_web_results if total_web_results > 0 else 0
            
            # 根據支持度調整信心度
            original_confidence = llm_result.get('confidence', 'medium')
            if support_ratio >= 0.67:  # 67%以上支持
                enhanced_confidence = 'high' if original_confidence in ['medium', 'low'] else original_confidence
                confidence_change = '提升'
            elif support_ratio >= 0.33:  # 33-66%支持
                enhanced_confidence = 'medium' if original_confidence == 'low' else original_confidence  
                confidence_change = '維持' if original_confidence != 'low' else '提升'
            else:  # 少於33%支持
                enhanced_confidence = 'low' if original_confidence == 'high' else original_confidence
                confidence_change = '降低' if original_confidence == 'high' else '維持'
            
            self.logger.info(f"📊 WebSearch支持度: {support_ratio:.1%}, 信心度{confidence_change}")
            
            return {
                'eccn_code': llm_result.get('eccn_code'),
                'confidence': enhanced_confidence,
                'method': 'llm_pipeline_websearch_enhanced',
                'reasoning': f"LLM分析結合WebSearch驗證 (支持度: {support_ratio:.1%})",
                'source': 'llm_with_websearch_enhancement',
                'llm_result': llm_result,
                'websearch_support': {
                    'support_ratio': support_ratio,
                    'support_count': support_count,
                    'total_results': total_web_results,
                    'confidence_change': confidence_change
                },
                'websearch_results': web_results[:3],
                'version': 'v3.2_priority_system'
            }
            
        except Exception as e:
            self.logger.error(f"❌ WebSearch強化失敗: {str(e)}")
            # 失敗時返回原始LLM結果
            llm_result['websearch_error'] = str(e)
            return llm_result
    
    def _enhance_with_tools(self, base_classification: Dict, product_model: str, pdf_content: str) -> Dict:
        """保持舊版本兼容性 - 重定向到新的優先級系統"""
        self.logger.info("🔄 重定向到優先級分類系統...")
        return self._classify_with_priority_system(product_model, pdf_content, False)
    
    def _synthesize_enhancement_results(self, base_result: Dict, enhancement_results: Dict, product_model: str) -> Dict:
        """綜合工具增強結果"""
        
        self.logger.info("🔄 綜合分析工具增強結果...")
        
        # 收集所有ECCN建議
        eccn_suggestions = []
        
        # 基礎AI分類
        base_eccn = base_result.get('eccn_code', 'EAR99')
        eccn_suggestions.append({
            'source': 'ai_base',
            'eccn_code': base_eccn,
            'confidence': base_result.get('confidence', 'medium'),
            'weight': 1.0
        })
        
        # Mouser結果
        if 'mouser' in enhancement_results:
            mouser_data = enhancement_results['mouser']
            eccn_suggestions.append({
                'source': 'mouser',
                'eccn_code': mouser_data.get('eccn_code', 'EAR99'),
                'confidence': mouser_data.get('confidence', 'medium'),
                'weight': 3.0  # 高權重，因為是官方經銷商資料
            })
        
        # WebSearch結果
        if 'websearch' in enhancement_results:
            for web_result in enhancement_results['websearch']:
                confidence_weight = {
                    'high': 2.0,
                    'medium': 1.5,
                    'low': 0.5
                }.get(web_result.get('confidence', 'low'), 1.0)
                
                eccn_suggestions.append({
                    'source': 'websearch',
                    'eccn_code': web_result.get('eccn_code', 'EAR99'),
                    'confidence': web_result.get('confidence', 'low'),
                    'weight': confidence_weight
                })
        
        # 計算加權分數
        eccn_scores = {}
        for suggestion in eccn_suggestions:
            eccn = suggestion['eccn_code']
            weight = suggestion['weight']
            
            confidence_multiplier = {
                'high': 1.0,
                'medium': 0.8,
                'low': 0.5
            }.get(suggestion['confidence'], 0.5)
            
            score = weight * confidence_multiplier
            
            if eccn not in eccn_scores:
                eccn_scores[eccn] = {'score': 0, 'sources': [], 'details': []}
            
            eccn_scores[eccn]['score'] += score
            eccn_scores[eccn]['sources'].append(suggestion['source'])
            eccn_scores[eccn]['details'].append(suggestion)
        
        # 選擇最高分的ECCN
        if eccn_scores:
            best_eccn = max(eccn_scores.keys(), key=lambda x: eccn_scores[x]['score'])
            best_data = eccn_scores[best_eccn]
            
            # 決定最終信心度
            final_confidence = self._calculate_final_confidence(best_data, len(eccn_suggestions))
            
            # 決定是否覆蓋基礎分類
            override_threshold = TOOLS_CONFIG['tool_enhancement']['override_threshold']
            confidence_threshold = TOOLS_CONFIG['tool_enhancement']['confidence_threshold']
            
            if (best_eccn != base_eccn and 
                final_confidence in ['high', 'medium'] and 
                best_data['score'] >= override_threshold):
                
                decision = 'external_override'
                reasoning = f"外部工具高信心度覆蓋: {', '.join(set(best_data['sources']))}"
            elif best_eccn == base_eccn:
                decision = 'external_confirmation'
                reasoning = f"外部工具確認基礎分類: {', '.join(set(best_data['sources']))}"
            else:
                decision = 'base_maintained'
                reasoning = f"外部工具信心度不足，維持基礎分類"
                best_eccn = base_eccn
                final_confidence = base_result.get('confidence', 'medium')
            
            # 構建最終結果
            enhanced_result = {
                'eccn_code': best_eccn,
                'confidence': final_confidence,
                'method': 'tool_enhanced',
                'reasoning': reasoning,
                'enhancement_decision': decision,
                'base_classification': base_result,
                'enhancement_sources': list(enhancement_results.keys()),
                'eccn_analysis': eccn_scores,
                'tool_enhanced': True
            }
            
            return enhanced_result
        
        # 回退到基礎分類
        base_result['enhancement_note'] = '工具增強分析後維持基礎分類'
        return base_result
    
    def _calculate_final_confidence(self, best_data: Dict, total_suggestions: int) -> str:
        """計算最終信心度"""
        
        score = best_data['score']
        sources_count = len(set(best_data['sources']))
        
        # 歸一化分數
        max_possible_score = total_suggestions * 3.0  # 假設最高權重為3.0
        normalized_score = score / max_possible_score if max_possible_score > 0 else 0
        
        # 多來源加分
        source_bonus = min(sources_count / 3.0, 1.0)
        
        final_score = (normalized_score + source_bonus) / 2
        
        if final_score >= 0.8:
            return 'high'
        elif final_score >= 0.6:
            return 'medium'
        else:
            return 'low'
    
    def _extract_manufacturer(self, pdf_content: str, product_model: str) -> Optional[str]:
        """從PDF內容或產品型號中提取製造商資訊"""
        
        # 常見製造商關鍵字
        manufacturers = {
            'advantech': ['advantech', 'eki-', 'uno-'],
            'moxa': ['moxa', 'tn-', 'cn-'],
            'cisco': ['cisco', 'catalyst'],
            'dell': ['dell', 'powerconnect'],
            'hp': ['hp', 'hewlett'],
            'siemens': ['siemens', 'scalance']
        }
        
        content_lower = pdf_content.lower()
        model_lower = product_model.lower()
        
        for manufacturer, keywords in manufacturers.items():
            for keyword in keywords:
                if keyword in content_lower or keyword in model_lower:
                    return manufacturer.title()
        
        return None
    
    def _find_similar_eccns(self, pdf_content: str) -> List[Dict]:
        """使用embeddings找到相似的ECCN案例"""
        
        if not self.eccn_embeddings:
            self.logger.warning("ECCN embeddings not available")
            return []
        
        try:
            self.logger.info("🔍 執行ECCN embeddings cosine similarity搜索...")
            
            # 計算PDF內容的embedding (簡化版本，使用TF-IDF相似度)
            pdf_words = set(pdf_content.lower().split())
            
            similarities = []
            
            # 對每個ECCN計算相似度
            for eccn_code, eccn_data in self.eccn_embeddings.items():
                if isinstance(eccn_data, dict) and 'text' in eccn_data:
                    eccn_text = eccn_data['text'].lower()
                    eccn_words = set(eccn_text.split())
                    
                    # 計算簡化的Jaccard相似度
                    intersection = len(pdf_words.intersection(eccn_words))
                    union = len(pdf_words.union(eccn_words))
                    
                    if union > 0:
                        similarity = intersection / union
                        
                        # 加權重要關鍵字
                        important_keywords = [
                            'switch', 'managed', 'network', 'ethernet', 'industrial',
                            'gigabit', 'vlan', 'snmp', 'qos', 'security', 'encryption',
                            'modbus', 'temperature', 'management'
                        ]
                        
                        keyword_bonus = 0
                        for keyword in important_keywords:
                            if keyword in pdf_content.lower() and keyword in eccn_text:
                                keyword_bonus += 0.1
                        
                        final_similarity = min(similarity + keyword_bonus, 1.0)
                        
                        if final_similarity > 0.1:  # 只保留有意義的相似度
                            similarities.append({
                                'eccn': eccn_code,
                                'similarity': round(final_similarity, 3),
                                'description': eccn_text[:100] + '...' if len(eccn_text) > 100 else eccn_text
                            })
            
            # 排序並返回前5個最相似的
            similarities.sort(key=lambda x: x['similarity'], reverse=True)
            top_similarities = similarities[:5]
            
            self.logger.info(f"✅ 找到 {len(top_similarities)} 個相似ECCN案例")
            for sim in top_similarities:
                self.logger.info(f"  - {sim['eccn']}: {sim['similarity']:.3f}")
            
            return top_similarities
            
        except Exception as e:
            self.logger.error(f"❌ ECCN embeddings相似度搜索失敗: {str(e)}")
            # 回退到預設案例
            return [
                {'eccn': '5A991', 'similarity': 0.85, 'description': 'Industrial Ethernet switch'},
                {'eccn': 'EAR99', 'similarity': 0.75, 'description': 'Commercial networking equipment'},
                {'eccn': '5A992.c', 'similarity': 0.80, 'description': 'High-end managed network equipment'}
            ]
    
    def _build_classification_prompt(self, similar_eccns: List[Dict]) -> str:
        """構建分類提示詞"""
        
        prompt = """You are an ECCN (Export Control Classification Number) expert. Please classify products accurately based on technical specifications.

ECCN Classification Standards:

## EAR99 (Commercial Grade)
- Temperature Range: 0-70°C (standard office environment)
- Power: 100-240VAC only
- Features: Commercial, office, consumer grade, basic functionality, unmanaged

## 5A991 (Industrial Grade Network Equipment)  
- Temperature Range: -40°C to 85°C (industrial environment)
- Power: DC power supply or AC/DC hybrid
- Features: Industrial networking, DIN-rail mounting, rugged design
- Characteristics: Basic industrial grade with relatively simple functionality

## 5A991.b (Security Enhanced Industrial)
- Based on 5A991, but additionally features:
- Encryption capabilities, VPN support, firewall, authentication mechanisms
- Focus: Primarily security/encryption-centric features

## 5A991.b.1 (High-Speed Network)
- Based on 5A991, features:
- Gigabit or higher speed, fiber interfaces, backbone network capability

## 4A994 (Network Management Equipment)
- Dedicated to network management and monitoring
- SNMP management, supervisory control functions

## 5A992.c (High-End Managed Network Equipment)
- **Key Identification**: Explicitly labeled as "Entry-Level Managed Switch" or "Managed Switch"
- Industrial-grade hardware + advanced management capabilities
- Management Functions: SNMP v1/v2c/v3, WEB GUI, CLI management
- Advanced Features: QoS, VLAN, Link Aggregation, 802.1X authentication
- Industrial Protocols: Modbus/TCP support
- Performance Metrics: **Switching Capacity ≥10Gbps** (critical threshold)
- Security Features: Port security, MAC filtering, access control

## Classification Decision Priority:

**First Priority - Product Explicit Definition**:
1. If product explicitly labeled "Entry-Level Managed Switch" → Strong indication of 5A992.c
2. If product labeled "Managed Switch" series → Points to 5A992.c

**Second Priority - Performance Threshold**:
1. Switching Capacity ≥20Gbps → Strong indication of 5A992.c
2. Switching Capacity ≥10Gbps + management functions → Points to 5A992.c

**Third Priority - Feature Combination**:
1. Management functions (SNMP/WEB) + QoS + VLAN + Link Aggregation → 5A992.c
2. Only security features without management functions → 5A991.b
3. Only industrial-grade hardware with simple functionality → 5A991

**Key Decision Principles**:
- **5A992.c vs 5A991.b**: If "Managed Switch" with comprehensive management functions → 5A992.c
- **5A991.b applies to**: Devices primarily focused on encryption/security with simpler management
- **5A992.c applies to**: Explicit managed switches with enterprise-grade management and high performance

Please analyze product technical specifications and provide:
1. ECCN Code
2. Confidence Level (high/medium/low)
3. Classification Rationale

Response Format:
{
  "eccn_code": "Classification Code",
  "confidence": "Confidence Level", 
  "reasoning": "Detailed classification rationale"
}"""
        
        if similar_eccns:
            prompt += f"\n\n參考相似案例:\n"
            for case in similar_eccns[:3]:
                prompt += f"- {case['eccn']}: {case['description']} (相似度: {case['similarity']})\n"
        
        return prompt
    
    def _call_bedrock(self, system_prompt: str, user_message: str) -> str:
        """調用Bedrock API"""
        
        try:
            body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 4000,
                "system": system_prompt,
                "messages": [
                    {
                        "role": "user",
                        "content": user_message
                    }
                ]
            }
            
            response = self.bedrock_client.invoke_model(
                modelId=BEDROCK_MODEL_ID,
                body=json.dumps(body)
            )
            
            response_body = json.loads(response['body'].read())
            return response_body['content'][0]['text']
            
        except Exception as e:
            self.logger.error(f"Bedrock調用失敗: {str(e)}")
            raise
    
    def _parse_bedrock_response(self, response_text: str) -> Dict:
        """解析Bedrock回應"""
        
        try:
            # 尋找JSON格式回應
            json_match = re.search(r'\{[^}]*\}', response_text, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            
            # 回退解析
            eccn_match = re.search(r'(EAR99|[0-9][A-Z][0-9]{3}(?:\.[a-z](?:\.[0-9]+)?)?)', response_text)
            eccn_code = eccn_match.group(1) if eccn_match else 'EAR99'
            
            return {
                'eccn_code': eccn_code,
                'confidence': 'medium',
                'reasoning': response_text[:500] + '...' if len(response_text) > 500 else response_text
            }
            
        except Exception as e:
            self.logger.error(f"回應解析失敗: {str(e)}")
            return {
                'eccn_code': 'EAR99',
                'confidence': 'low',
                'reasoning': f'回應解析失敗，使用預設值: {str(e)}'
            }
    
    def _create_success_response(self, classification: Dict) -> Dict:
        """創建成功回應"""
        return {
            'statusCode': 200,
            'body': {
                'success': True,
                'classification': classification
            }
        }
    
    def _create_error_response(self, error_message: str, s3_key: str = None) -> Dict:
        """創建錯誤回應"""
        return {
            'statusCode': 500,
            'body': {
                'success': False,
                'error': error_message,
                's3_key': s3_key,
                'timestamp': datetime.now().isoformat()
            }
        }

# Lambda入口點
def lambda_handler(event, context):
    """Lambda函數入口點"""
    
    try:
        # 解析輸入
        if isinstance(event.get('body'), str):
            body = json.loads(event['body'])
        else:
            body = event.get('body', event)
        
        s3_key = body.get('s3_key')
        product_model = body.get('product_model', 'Unknown')
        debug = body.get('debug', False)
        
        if not s3_key:
            return {
                'statusCode': 400,
                'body': {
                    'success': False,
                    'error': '缺少必需參數: s3_key'
                }
            }
        
        # 創建分類器並執行分類
        classifier = EnhancedECCNClassifier()
        result = classifier.classify_product(s3_key, product_model, debug)
        
        return result
        
    except Exception as e:
        return {
            'statusCode': 500,
            'body': {
                'success': False,
                'error': f'Lambda執行失敗: {str(e)}',
                'timestamp': datetime.now().isoformat()
            }
        }

# 本地測試
def test_enhanced_classifier():
    """本地測試函數"""
    
    test_event = {
        'body': {
            's3_key': 'parsed/pdf_20250724_141513_ff372770.json',
            'product_model': 'EKI-2428G-4CA-AE',
            'debug': True
        }
    }
    
    result = lambda_handler(test_event, None)
    
    print("🧪 增強型分類器測試結果:")
    print(json.dumps(result, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    test_enhanced_classifier()