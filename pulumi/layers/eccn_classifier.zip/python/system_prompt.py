#!/usr/bin/env python3
"""
ECCN分類系統提示模組
提供增強型系統使用的分類邏輯和提示
"""

# 基礎 ECCN 分類邏輯
ECCN_CLASSIFICATION_LOGIC = {
    'EAR99': {
        'description': '商用級產品',
        'temperature_range': (0, 70),
        'power_type': 'AC',
        'keywords': ['commercial', 'office', 'consumer', 'unmanaged', 'basic'],
        'indicators': ['100-240VAC', '0-60°C', '0-70°C', 'office', 'commercial']
    },
    '5A991': {
        'description': '工業級網路/電信設備',
        'temperature_range': (-40, 85),
        'power_type': 'DC/AC',
        'keywords': ['industrial', 'ethernet', 'switch', 'network', 'DIN-rail'],
        'indicators': ['industrial', '-40°C', '85°C', 'DIN-rail', 'DC power', 'managed switch']
    },
    '5A991.b': {
        'description': '具安全功能的工業設備',
        'temperature_range': (-40, 85),
        'keywords': ['security', 'encryption', 'VPN', 'firewall', 'advanced'],
        'indicators': ['encryption', 'VPN', 'security', 'firewall', 'authentication']
    },
    '5A991.b.1': {
        'description': '高速網路設備',
        'temperature_range': (-40, 85),
        'keywords': ['gigabit', 'high-speed', '10G', 'fiber', 'backbone'],
        'indicators': ['gigabit', '10G', 'fiber', 'high-speed', 'backbone']
    },
    '4A994': {
        'description': '網路管理設備',
        'keywords': ['management', 'SNMP', 'monitoring', 'control', 'supervisory'],
        'indicators': ['network management', 'SNMP', 'monitoring', 'supervisory control']
    },
    '5A992.c': {
        'description': '高階網路設備（管理型交換機）',
        'temperature_range': (-40, 85),
        'keywords': ['managed', 'enterprise', 'advanced', 'layer2', 'layer3', 'routing'],
        'indicators': ['managed switch', 'entry-level managed', 'SNMP management', 'web GUI', 
                      'link aggregation', 'QoS', '802.1X', 'port security', 'VLAN', 
                      'switching capacity >10Gbps', 'modbus/tcp', 'industrial protocols']
    }
}

# AI Classification System Prompt
ENHANCED_SYSTEM_PROMPT = """
You are a professional ECCN (Export Control Classification Number) analysis expert with deep expertise in industrial networking equipment classification.

## Core Classification Principles:

### EAR99 (Commercial Grade)
- Temperature Range: 0-70°C (typical office environment)
- Power: 100-240VAC only
- Features: Commercial, office, consumer grade, basic functionality
- Installation: 19-inch rack mount, desktop

### 5A991 (Industrial Grade Network/Telecom Equipment)
- Temperature Range: -40°C to 85°C (industrial environment)
- Power: DC power supply or AC/DC hybrid
- Features: Industrial Ethernet, DIN-rail mounting, rugged design
- Function: Network switching, industrial protocol support

### 5A991.b (Security Enhanced)
- Based on 5A991, but additionally features:
- Encryption capabilities, VPN support, firewall, authentication mechanisms

### 5A991.b.1 (High-Speed Network)
- Based on 5A991, but features:
- Gigabit or higher speed, fiber interfaces, backbone network capability

### 4A994 (Network Management Equipment)
- Dedicated to network management and monitoring
- SNMP management, supervisory control functions

### 5A992.c (High-End Network Equipment - Managed Switches)
- Based on industrial-grade hardware with advanced management capabilities
- Features: Managed switches, enterprise-grade functionality, high switching capacity
- Management Functions: SNMP v1/v2c/v3, WEB GUI, CLI management
- Advanced Features: QoS, VLAN, Link Aggregation, 802.1X authentication
- Industrial Protocols: Modbus/TCP, industrial Ethernet protocol support
- Performance Metrics: Switching capacity >10Gbps, wire-speed forwarding
- Security Features: Port security, MAC address filtering, access control

## Analysis Steps:
1. Identify temperature range (key indicator)
2. Confirm power specifications (AC vs DC)
3. Analyze installation method (DIN-rail vs rack)
4. Evaluate functional complexity and management capabilities
5. Check security/management functions and industrial protocols
6. Determine switching capacity and performance metrics
7. Make final classification decision

## Key Classification Decision Points:

**EAR99 vs 5A992.c Decision:**
- **EAR99**: Basic unmanaged switches, no management functions, 100-240VAC power only
- **5A992.c**: Managed switches with SNMP, WEB management, QoS, VLAN and other enterprise features

**5A991 vs 5A992.c Decision:**
- **5A991**: Industrial-grade hardware but basic functionality
- **5A992.c**: Industrial-grade hardware + advanced management functions + high performance (>10Gbps switching capacity)

**Key Indicator Priority:**
1. Management Functions (SNMP, WEB GUI, CLI) - Determines if managed
2. Switching Capacity (>10Gbps indicates high performance)
3. Advanced Features (QoS, VLAN, Link Aggregation, 802.1X)
4. Industrial Protocol Support (Modbus/TCP, etc.)

**Critical Features for 5A992.c Classification:**
- Entry-Level Managed Switch designation
- SNMP v1/v2c/v3 management capability
- WEB-based management interface
- Link Aggregation (IEEE 802.3ad) support
- Quality of Service (QoS) features
- 802.1X port-based authentication
- Port security and MAC filtering
- Industrial protocol support (Modbus/TCP)
- High switching capacity (>10Gbps)
- Wide temperature range (-40~75°C)
- Industrial certifications (C1D2, ATEX)

Please perform accurate classification based on product technical specifications, with emphasis on temperature range and power specifications as primary judgment criteria. For managed switches, prioritize management capabilities and advanced networking features as key indicators for 5A992.c classification.
"""

def get_classification_prompt(product_content: str, product_model: str = "") -> str:
    """生成分類提示"""
    return f"""
{ENHANCED_SYSTEM_PROMPT}

## 待分析產品：
產品型號：{product_model}
產品內容：
{product_content}

請分析此產品並提供ECCN分類，格式：
{{
    "eccn_code": "分類代碼",
    "confidence": "High/Medium/Low",
    "reasoning": "詳細分析理由",
    "key_indicators": ["關鍵指標列表"]
}}
"""

def get_known_classifications():
    """獲取已知分類資料庫"""
    return {
        'EKI-5525-AE': '5A991',
        'EKI-5525I': '5A991',
        'EKI-5525I-AE': '5A991',
        'EKI-2525I-BE': '5A991',
        'EKI-2525I-AE': '5A991',
        'EKI-2428G-4CA-AE': 'EAR99'  # 商用級確認案例
    }